package com.perfulandia.boletaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoletaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
