package com.perfulandia.boletaservice.controllerTest;

import com.perfulandia.boletaservice.controller.BoletaController;
import com.perfulandia.boletaservice.controller.BoletaController.*;
import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.service.BoletaService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
//2 Anotación para probar solo el controlador (no el contexto completo de Spring Boot)
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//3 Anotación para simular un bean dentro del ApplicationContext de Spring
import org.springframework.test.context.bean.override.mockito.MockitoBean;
//4 Inyección automática del cliente de pruebas web
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
//5 Métodos estáticos de Mockito
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
//6 Métodos para construir peticiones HTTP simuladas y verificar respuestas
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
//7 Librería para convertir objetos a JSON (necesaria en peticiones POST)
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.ResultMatcher;

import java.time.LocalDate;
import java.util.List;


//Anotación para indicar que en esta clase se realizará testing del controlador
@WebMvcTest(BoletaController.class)
public class BoletaControllerTest {

    //Injectando Mokck  para utilizar dentro de esta clase
    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BoletaService service;
    private BoletaController boletaController;

    //Convertir de texto a JSON y vicecver
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    @DisplayName("TESTING 1 - GET /api/boletas")
    void testGetAll() throws Exception {
        Boleta boleta = new Boleta(
                1L,
                "Renato",
                "ren.vera@duocuc.cl",
                "Strong with you",
                120000,
                LocalDate.of(2025, 6, 27)
        );

        when(service.listar()).thenReturn(List.of(boleta));

        mockMvc.perform(get("/api/boletas"))
                .andDo(print()) // muestra en consola el JSON de respuesta
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombreUsuario").value("Renato"))  // ← campo correcto
                .andExpect(jsonPath("$[0].nombreProducto").value("Strong with you 100ml"));
    }


    @Test
    @DisplayName("TESTING 2 - POST /api/boletas/emitir")
    void testEmitirBoleta() throws Exception {
        Boleta b = new Boleta(1L, "Renato", "ren.vera@gmail.cl", "Strong with you 100ml", 120000, LocalDate.of(2025, 7, 2));
        when(service.emitirBoleta(1L, 1L)).thenReturn(b);

        mockMvc.perform(post("/api/boletas/emitir")
                        .param("usuarioId", "1")
                        .param("productoId", "1"))
                .andDo(print()) // para ver la respuesta en consola
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreUsuario").value("Renato"))
                .andExpect(jsonPath("$.nombreProducto").value("Strong with you 100ml"));
    }


}
