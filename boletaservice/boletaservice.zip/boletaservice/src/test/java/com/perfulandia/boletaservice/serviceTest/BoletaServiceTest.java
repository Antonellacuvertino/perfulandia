package com.perfulandia.boletaservice.serviceTest;

import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.repository.BoletaRepository;
import com.perfulandia.boletaservice.service.BoletaService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import org.mockito.*;
import org.mockito.Mockito.*;

public class BoletaServiceTest {

    //Creando instancia para injectar mocks
    @InjectMocks
    private BoletaService service;
    //Creando una instancia para reemplazar el repository por datos simulados
    @Mock
    private BoletaRepository repo;

    //Constructor
    public BoletaServiceTest() {
        //inicializar los mocks anotados para el test
        MockitoAnnotations.openMocks(this);
    }
    @Test
    @DisplayName("Testing 1 al servicio del metodo FindAll(Buscar)")
    void testFindAll(){

        //1 Simular al repo y a simular una boleta
        when(repo.findAll()).thenReturn(List.of(new Boleta(1L,"Renato","ren.vera@duocuc.cl","Strong with you 100ml",120000, LocalDate.of(2025,6,27))));

        //2 Llamamos al metodo del servicio que será probado
        List<Boleta> resultado= service.listar();

        //3 Verificar que los datos simulados tengan coincidencia
        assertEquals(1,resultado.size());
    }
}
