package com.perfulandia.usuarioservice.controller;

import com.perfulandia.usuarioservice.model.Usuario;
import com.perfulandia.usuarioservice.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@Tag(name = "Usuarios", description = "Operaciones CRUD para gestión de usuarios")
public class UsuarioController {

    private final UsuarioService service;

    // Constructor para inyectar el servicio
    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Listar todos los usuarios", description = "Obtiene una lista completa de los usuarios registrados")
    @ApiResponse(responseCode = "200", description = "Usuarios obtenidos correctamente")
    public List<Usuario> listar() {
        return service.listar();
    }

    @PostMapping
    @Operation(summary = "Guardar un nuevo usuario", description = "Registra un nuevo usuario en la base de datos")
    @ApiResponse(responseCode = "201", description = "Usuario creado correctamente")
    public Usuario guardar(@RequestBody Usuario usuario) {
        return service.guardar(usuario);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar usuario por ID", description = "Obtiene un usuario específico mediante su ID")
    @ApiResponse(responseCode = "200", description = "Usuario encontrado correctamente")
    public Usuario buscar(@PathVariable long id) {
        return service.buscar(id);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar usuario por ID", description = "Elimina un usuario existente mediante su ID")
    @ApiResponse(responseCode = "204", description = "Usuario eliminado correctamente")
    public void eliminar(@PathVariable long id) {
        service.eliminar(id);
    }
}
