package com.perfulandia.usuarioservice.controller;

import com.perfulandia.usuarioservice.model.Usuario;
import com.perfulandia.usuarioservice.service.UsuarioService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private UsuarioService usuarioService;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void testBuscarUsuarioPorId() throws Exception {
		Usuario usuario = Usuario.builder()
				.id(1L)
				.nombre("Antonella")
				.correo("antonella@mail.com")
				.rol("ADMIN")
				.build();

		when(usuarioService.buscar(1L)).thenReturn(usuario);

		mockMvc.perform(get("/api/usuarios/1"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.nombre").value("Antonella"))
				.andExpect(jsonPath("$.correo").value("antonella@mail.com"));
	}

	@Test
	public void testGuardarUsuario() throws Exception {
		Usuario usuario = Usuario.builder()
				.id(1L)
				.nombre("Nuevo")
				.correo("nuevo@mail.com")
				.rol("GERENTE")
				.build();

		when(usuarioService.guardar(any(Usuario.class))).thenReturn(usuario);

		mockMvc.perform(post("/api/usuarios")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(usuario)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.nombre").value("Nuevo"))
				.andExpect(jsonPath("$.rol").value("GERENTE"));
	}
}
