package com.perfulandia.usuarioservice.service;

import com.perfulandia.usuarioservice.model.Usuario;
import com.perfulandia.usuarioservice.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UsuarioServiceTest {

	@Mock
	private UsuarioRepository usuarioRepository;

	@InjectMocks
	private UsuarioService usuarioService;

	public UsuarioServiceTest() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testBuscarUsuarioExistente() {
		Usuario usuario = Usuario.builder()
				.id(1L)
				.nombre("Antonella")
				.correo("antonella@mail.com")
				.rol("ADMIN")
				.build();

		when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

		Usuario resultado = usuarioService.buscar(1L);

		assertNotNull(resultado);
		assertEquals("Antonella", resultado.getNombre());
		verify(usuarioRepository).findById(1L);
	}

	@Test
	public void testGuardarUsuario() {
		Usuario nuevo = Usuario.builder()
				.nombre("Nuevo")
				.correo("nuevo@mail.com")
				.rol("GERENTE")
				.build();

		Usuario guardado = Usuario.builder()
				.id(1L)
				.nombre("Nuevo")
				.correo("nuevo@mail.com")
				.rol("GERENTE")
				.build();

		when(usuarioRepository.save(nuevo)).thenReturn(guardado);

		Usuario resultado = usuarioService.guardar(nuevo);

		assertNotNull(resultado.getId());
		assertEquals("Nuevo", resultado.getNombre());
		verify(usuarioRepository).sa
